from msg import joint_angle.msg

print '\n It worked \n'
